<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

//LOCATION : application - controller - Auth.php

class Seller extends CI_Controller {

    private $app_name;

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Common_model','common_model');
        $this->load->model('adm_model');
        $this->load->model('Setting_model');

        $app_setting = $this->Setting_model->get_details();
        
        $this->app_name=$app_setting->app_name;
    }

    public function index(){
        $data = array();

        if($this->session->userdata('is_login') == TRUE){
            redirect(base_url() . 'vendor/pages/dashboard', 'refresh');
        }

        $data['page_title'] = $this->lang->line('login_lbl');
        $this->load->view('vendor/page/login', $data);
    }

    public function forgot_password(){
        $data = array();

        $data['page_title'] = $this->lang->line('forgot_password_lbl');
        $this->load->view('vendor/page/forgot_password', $data);
    }

    public function login(){ 
  
        $this->form_validation->set_rules('username', 'Username', 'required');  
        $this->form_validation->set_rules('password', 'Password', 'required'); 

        if($this->form_validation->run())  
        {
             if($_POST)
             { 
                $query = $this->adm_model->validate_admin();
                
                //-- if valid
                if($query){
                    $data = array();
                    foreach($query as $row){
                        $data = array(
                            'id' => $row->id,
                            'username' => $row->user_name,
                            'email' =>$row->user_email,
                            'is_login' => TRUE
                        );
                        $this->session->set_userdata($data);
                        $url = base_url('dashboard');
                    }
                    redirect(base_url() . 'vendor/pages/dashboard', 'refresh');
                }else{

                    $message = array('message' => $this->lang->line('invalid_login_msg'),'class' => 'alert-danger');
                    $this->session->set_flashdata('response_msg', $message);
                    $this->index();
                }
                
            }
            else{
                redirect(base_url() . 'Seller', 'refresh');
            }
        }
        else  
        {  
            $message = array('message' => $this->lang->line('input_required'),'class' => 'alert-danger');
            $this->session->set_flashdata('response_msg', $message);
            redirect(base_url() . 'Seller');
        }
    }

    public function forgot_password_form(){ 
  
        $this->form_validation->set_rules('email', $this->lang->line('email_require_lbl'), 'required');

        if($this->form_validation->run())  
        {
             if($_POST)
             { 

                $email=$this->input->post('email');

                $query = $this->adm_model->validate_admin_date(array('user_email' => $email));
                
                //-- if valid
                if($query){
                    $data = array();
                    $row=$query[0];

                    $info['new_password']=get_random_password();

                    $updateData = array(
                        'user_password' => md5($info['new_password'])
                    );

                    $data_arr = array(
                        'name' => $row->user_name,
                        'email' => $row->user_email,
                        'password' => $info['new_password']
                    );

                    $subject = $this->app_name.' - '.$this->lang->line('forgot_password_lbl');

                    $body = $this->load->view('admin/emails/forgot_password.php',$data_arr,TRUE);

                    if(send_email($row->user_email, $row->user_name, $subject, $body))
                    {
                        $this->common_model->update($updateData, $row->id,'tbl_partner');

                        $message = array('success' => '1','message' => $this->lang->line('password_sent'),'class' => 'alert-success');
                        $this->session->set_flashdata('response_msg', $message);

                        redirect(base_url() . 'Seller');
                    }
                    else{
                        $message = array('success' => '0','message' => $this->lang->line('email_not_sent'),'class' => 'alert-danger');

                        redirect(base_url() . 'Seller/forgot_password');
                    }
                    
                }else{

                    $message = array('message' => $this->lang->line('email_not_found'),'class' => 'alert-danger');
                    $this->session->set_flashdata('response_msg', $message);
                    redirect(base_url() . 'Seller/forgot_password');
                }
                
            }
            else{
                redirect(base_url() . 'Seller/forgot_password');
            }
        }
        else  
        {  
            $message = array('message' => $this->lang->line('email_require_lbl'),'class' => 'alert-danger');
            $this->session->set_flashdata('response_msg', $message);
            redirect(base_url() . 'Seller/forgot_password');
        }
    }

    public function logout(){

        $array_items = array('id', 'username', 'email', 'is_login');

        $this->session->unset_userdata($array_items);

        redirect(base_url() . 'Seller', 'refresh');
    }

}