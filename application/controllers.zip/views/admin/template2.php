<!-- include your header view here -->
<?php $this->load->view('site/layout/header'); ?>

<?=$contents?>

<!-- include your footer view here -->
<?php $this->load->view('site/layout/footer'); ?>
 