
<!-- include your header view here -->
<?php $this->load->view('admin/layout/header'); ?>

<div class="pcoded-content">
    <div class="pcoded-inner-content">
        <div class="main-body">
            <div class="page-wrapper">
   				<?=$contents?>
 			</div>
 		</div>
 	</div>
</div>
<!-- include your footer view here -->
<?php $this->load->view('admin/layout/footer'); ?>
 